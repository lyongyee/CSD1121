// add a file documentation header as explained in the specs ...

// provide the declaration or prototype of a function squared
// that takes a parameter of type int and returns a value
// of type int [that is equivalent to the squared value of
// the int parameter] ...

// provide the declaration or prototype of a function cubed
// that takes a parameter of type double and returns a
// value of type double [that is equivalent to the cubed
// value of the double parameter] ...

// provide the declaration or prototype of function minus
// that takes a parameter of type double and returns a
// value of type double [that is equivalent to the negated
// value of the double parameter] ...
